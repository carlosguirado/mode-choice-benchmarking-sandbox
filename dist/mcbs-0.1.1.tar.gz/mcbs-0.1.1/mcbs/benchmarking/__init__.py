# mcbs/benchmarking/__init__.py

from .benchmark import Benchmark

__all__ = ['Benchmark']